#include <iostream>
#include <vector>
#include <conio.h>
#include <stdlib.h>
#include "battle.hpp"
#include "player.hpp"
#include "deck.hpp"
#include <fstream>

class Game
{
public:
    Game()
    {
        char choice;
        std::cout << "Do you want to load the previous game ? (y/n)";
        std::cin >> choice;
        if (choice == 'y' || choice == 'Y')
        {
            if (loadGame())
            {
                std::cout << "Let's continue our war!!" << std::endl;
                continueGame();
            }
            else
            {
                std::cout << "Failed to load the game. Starting a new war..." << std::endl;
                startGame();
            }
        }
        else
        {
            startGame();
        }
    }

    void startGame()
    {
        welcomeAndGetNumberOfPlayers();
        setPlayersInVector();
        continueGame();
    }
      void continueGame()
    {
        while (true)
        {
            playRound();
            if (battle.checkTheGameEndsOrNot(players, GameMap))
            {
                break;
            }
            char saveChoice;
            std::cout << "Do you want to save the game and exit? (y/n): ";
            std::cin >> saveChoice;
            if (saveChoice == 'y' || saveChoice == 'Y')
            {
                saveGame();
                exit(0); // Exit the program
            }
        }
    }

    void playRound()
    {
        specifyTheRound();
        showPlayersCard();
        battle.startBattle(players);
        battle.setPlayersNameForSpring(players); // before calculating the score, spring should be checked
        battle.calculatePlayersScore(players);
        std::cout << battle.checkWinnerOfTheRound(players, city) << std::endl;

        for (int i{}; i < players.size(); i++) // just for debug
        {
            std::cout << players[i].getName() << " : " << players[i].getTotalScore() << std::endl;
        }
        char ch = getch();
    }

    void display()
    {
        for (int i{}; i < players.size(); i++)
        {
            std::cout << players[i].getName() << " : ";
            std::vector<std::string> temp1 = players[i].getYellowCardsOnTable();
            std::vector<std::string> temp2 = players[i].getPurpleCardsOnTable();
            for (int j{}; j < players[i].getYellowCardsOnTable().size(); j++)
            {
                std::cout << temp1[j] << "  ";
            }
            for (int k{}; k < players[i].getPurpleCardsOnTable().size(); k++)
            {
                std::cout << temp2[k] << "  ";
            }
            std::cout << std::endl;
        }
        std::cout << std::endl
                  << "-----------------------------------------------------------------------------------------" << std::endl;
        for (int i{}; i < players.size(); i++)
        {
            std::cout << players[i].getName() << " : ";
            std::vector<std::string> temp = players[i].getCapturedCities();
            for (int j{}; j < players[i].getCapturedCities().size(); j++)
            {
                std::cout << temp[j] << "  ";
            }
            std::cout << std::endl;
            std::cout << "--------------------------------------------------------------------------------------------" << std::endl;
        }
    }

    void welcomeAndGetNumberOfPlayers()
    {
        std::cout << "***********************************************" << std::endl;
        std::cout << "*                                             *" << std::endl;
        std::cout << "*               Welcome to RAKAB              *" << std::endl;
        std::cout << "*                                             *" << std::endl;
        std::cout << "*  An adventure awaits in the world of cards! *" << std::endl;
        std::cout << "* Test your strategy and wit in this exciting *" << std::endl;
        std::cout << "*       game of skill and cunning. Enjoy!     *" << std::endl;
        std::cout << "*                                             *" << std::endl;
        std::cout << "***********************************************" << std::endl;
        std::cout << "please enter the number of players: ";
        std::cin >> numOfPlayers;
        while (numOfPlayers < 3 || numOfPlayers > 6)
        {
            std::cout << "Invalid number of players. Please enter a number between 3 and 6 : ";
            std::cin >> numOfPlayers;
        }
    }

    void setPlayersInVector()
    {
        for (int i{}; i < numOfPlayers; i++)
        {
            std::string name;
            std::cout << "Player" << i + 1 << " please enter your name: ";
            std::cin >> name;

            int age;
            std::cout << "Player" << i + 1 << " please enter your age: ";
            std::cin >> age;
            while (age <= 0) // check that age is bigger than 0 or not
            {
                std::cout << "invalid age!please enter your age correctly: ";
                std::cin >> age;
            }

            std::string color;
            std::cout << "Player" << i + 1 << " please enter your color: ";
            std::cin >> color;

            std::vector<std::string> cardsInHand = deck.pakhsh();

            Player p(name, age, color, cardsInHand);
            players.push_back(p);
        }
    }

    void showPlayersCard()
    {
        for (int i{}; i < players.size(); i++)
        {
            char ch = getch();
            std::vector<std::string> temp = players[i].getCardsInHand();
            std::cout << players[i].getName() << " 's cards: ";
            for (int j{}; j < temp.size(); j++)
            {
                std::cout << temp[j] << " ";
            }
            std::cout << std::endl;
            ch = getch();
            system("CLS");
        }
    }

    int getRound()
    {
        return round;
    }
    void specifyTheRound()
    {
        if (round == 1)
        {
            Player temp = players[0];
            for (int i{}; i < players.size(); i++)
            {
                if (temp.getAge() > players[i].getAge())
                {
                    temp = players[i];
                }
            }
            std::string province;
            while (true)
            {
                std::cout << temp.getName() << " please choose province for battle: ";
                std::cin >> province;
                city = province;
                if (GameMap.isValidCity(province))
                {
                    break;
                }
                else
                {
                    std::cout << "Invalid city name. Please enter a valid city name ... " << std::endl;
                }
            }
            battle.setNeshanJang(province);
            round++;
        }
        else
        {
            for (int i{}; i < players.size(); i++)
            {
                players[i].setPass(false);
            }

            for (int i{}; i < players.size(); i++)
            {
                if (players[i].getWinnerForNeshanJang())
                {
                    std::string province;
                    while (true)
                    {
                        std::cout << players[i].getName() << " please choose province for battle: ";
                        std::cin >> province;
                        if (GameMap.isValidCity(province))
                        {
                            break;
                        }
                        else
                        {
                            std::cout << "Invalid city name. Please enter a valid city name: ";
                        }
                    }
                    battle.setNeshanJang(province);
                    city = province;
                    round++;
                    break;
                }
            }
        }
    }

    void saveGame()
    {
        std::ofstream file("game_save.txt");
        if (file.is_open())
        {
            file << round << '\n';
            file << numOfPlayers << '\n';
            file << city << '\n';
            for (const auto &player : players)
            {
                file << player.getName() << ' ' << player.getAge() << ' ' << player.getColor() << '\n';
                for (const auto &card : player.getCardsInHand())
                {
                    file << card << ' ';
                }
                file << "|\n";
                for (const auto &yellowCard : player.getYellowCardsOnTable())
                {
                    file << yellowCard << ' ';
                }
                file << "|\n";
                for (const auto &purpleCard : player.getPurpleCardsOnTable())
                {
                    file << purpleCard << ' ';
                }
                file << "|\n";
                for (const auto &city : player.getCapturedCities())
                {
                    file << city << ' ';
                }
                file << "|\n";
                file << player.getTotalScore() << '\n';
            }
            file.close();
        }
        else
        {
            std::cerr << "Unable to open file for saving!" << std::endl;
        }
    }

    bool loadGame()
    {
        std::ifstream file("game_save.txt");
        if (file.is_open())
        {
            file >> round;
            file >> numOfPlayers;
            file >> city;
            players.clear();
            for (int i = 0; i < numOfPlayers; i++)
            {
                std::string name, color;
                int age, score;
                file >> name >> age >> color;
                Player player(name, age, color);

                std::vector<std::string> cardsInHand;
                std::string card;
                while (file >> card && card != "|")
                {
                    cardsInHand.push_back(card);
                }
                player.setCardsInHand(cardsInHand);

                while (file >> card && card != "|")
                {
                    player.setYellowCardsOnTable(card);
                }

                while (file >> card && card != "|")
                {
                    player.setPurpleCardsOnTable(card);
                }

                while (file >> card && card != "|")
                {
                    player.setCapturedCities(card);
                }

                file >> score;
                player.setTotalScore(score);
                players.push_back(player);
            }
            file.close();
            return true;
        }
        else 
        {
            std::cerr << "Unable to open file for loading!" << std::endl;
            return false;
        }
    }

private : 
std::string city;
CityMap GameMap;
int numOfPlayers;
std::vector<Player> players;
Deck deck;
Battle battle;
int round = 1;
}
;