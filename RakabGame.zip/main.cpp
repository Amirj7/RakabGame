#include <iostream>
#include "game.hpp"

int main()
{
    Game game;
    game.startGame();

    return 0;
}